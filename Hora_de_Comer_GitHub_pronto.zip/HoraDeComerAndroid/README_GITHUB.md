# Gerar o APK pelo GitHub

1. No GitHub, crie um repositório vazio chamado `hora-de-comer`.
2. Extraia este ZIP no celular.
3. Envie o CONTEÚDO da pasta `HoraDeComerAndroid` para a raiz do repositório (incluindo a pasta oculta `.github`). Não envie apenas o ZIP.
4. Abra a aba **Actions** do repositório. Se aparecer um aviso, permita executar workflows.
5. Selecione **Build Hora de Comer APK** e toque em **Run workflow**. Também inicia quando você envia os arquivos para a branch `main`.
6. Quando terminar com sucesso, abra a execução e baixe **Hora-de-Comer-APK** na seção **Artifacts**.
7. Extraia o arquivo baixado e instale `app-debug.apk`. O Android poderá pedir permissão para instalar apps dessa fonte.

Se a compilação falhar, abra a execução e consulte o log do passo **Compilar APK**. Este fluxo tenta compilar o código; não garante que a primeira compilação passe sem ajustes.
