package br.com.joaofelipe.horadecomer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("meal_prefs", MODE_PRIVATE) }
    private val timeLabels = mutableMapOf<Int, TextView>()
    private val switches = mutableMapOf<Int, Switch>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        buildUi()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(0xFFF2F8F7.toInt()) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
        }
        scroll.addView(root)
        val header = TextView(this).apply {
            text = "⏰  Hora de Comer"
            textSize = 27f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(18), dp(22), dp(18), dp(5))
            setBackgroundColor(0xFF185D57.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(header)
        val subtitle = TextView(this).apply {
            text = "Olá, João Felipe!\nOrganize seus lembretes de refeições."
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(18), 0, dp(18), dp(20))
            setBackgroundColor(0xFF185D57.toInt())
        }
        root.addView(subtitle)
        addText(root, "Seus horários", 21f, true, 0xFF183432.toInt(), 20, 12)
        MealData.meals.forEach { meal ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setBackgroundColor(0xFFFFFFFF.toInt())
                elevation = dp(2).toFloat()
            }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val title = TextView(this).apply {
                text = "${meal.emoji}  ${meal.name}"
                textSize = 17f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(0xFF183432.toInt())
            }
            top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
            val enabled = prefs.getBoolean("enabled_${meal.id}", true)
            val toggle = Switch(this).apply {
                isChecked = enabled
                text = "Ativo"
                setTextColor(0xFF5D7774.toInt())
                setOnCheckedChangeListener { _, checked ->
                    prefs.edit().putBoolean("enabled_${meal.id}", checked).apply()
                    if (checked) AlarmScheduler.schedule(this@MainActivity, meal.id)
                    else AlarmScheduler.cancel(this@MainActivity, meal.id)
                }
            }
            switches[meal.id] = toggle
            top.addView(toggle)
            card.addView(top)
            addText(card, meal.description, 14f, false, 0xFF5D7774.toInt(), 3, 8)
            val time = TextView(this).apply {
                textSize = 19f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(0xFF217A70.toInt())
                setPadding(0, dp(5), 0, dp(3))
                text = getTimeLabel(meal.id, meal.defaultHour, meal.defaultMinute)
                isClickable = true
                setOnClickListener { showTimePicker(meal.id, meal.defaultHour, meal.defaultMinute) }
            }
            timeLabels[meal.id] = time
            card.addView(time)
            val hint = TextView(this).apply {
                text = "Toque no horário para alterar"
                textSize = 12f
                setTextColor(0xFF6A827F.toInt())
            }
            card.addView(hint)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(12)
            root.addView(card, lp)
        }
        val save = Button(this).apply {
            text = "Salvar e programar alarmes"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF217A70.toInt()))
            setOnClickListener {
                AlarmScheduler.scheduleAll(this@MainActivity)
                Toast.makeText(this@MainActivity, "Horários salvos! Os lembretes diários foram programados.", Toast.LENGTH_LONG).show()
                askExactAlarmPermissionIfNeeded()
            }
        }
        root.addView(save, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        val test = Button(this).apply {
            text = "Testar notificação"
            setOnClickListener {
                val intent = Intent(this@MainActivity, MealAlarmReceiver::class.java).putExtra("meal_id", 1)
                sendBroadcast(intent)
            }
        }
        root.addView(test, LinearLayout.LayoutParams(-1, -2))
        addText(root, "Dica: mantenha as notificações permitidas e confira o volume do celular. Os horários são sugestões; adapte à sua rotina e à sua fome.", 13f, false, 0xFF5D7774.toInt(), 18, 0)
        setContentView(scroll)
    }

    private fun addText(parent: LinearLayout, value: String, size: Float, bold: Boolean, color: Int, top: Int, bottom: Int) {
        val tv = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(top), 0, dp(bottom))
        }
        parent.addView(tv)
    }

    private fun getTimeLabel(id: Int, defaultHour: Int, defaultMinute: Int): String {
        val hour = prefs.getInt("hour_$id", defaultHour)
        val minute = prefs.getInt("minute_$id", defaultMinute)
        return String.format(Locale.getDefault(), "⏰  %02d:%02d", hour, minute)
    }

    private fun showTimePicker(id: Int, defaultHour: Int, defaultMinute: Int) {
        val hour = prefs.getInt("hour_$id", defaultHour)
        val minute = prefs.getInt("minute_$id", defaultMinute)
        TimePickerDialog(this, { _, h, m ->
            prefs.edit().putInt("hour_$id", h).putInt("minute_$id", m).apply()
            timeLabels[id]?.text = getTimeLabel(id, defaultHour, defaultMinute)
            if (prefs.getBoolean("enabled_$id", true)) AlarmScheduler.schedule(this, id)
        }, hour, minute, true).show()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
        }
    }

    private fun askExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!manager.canScheduleExactAlarms()) {
                AlertDialog.Builder(this)
                    .setTitle("Permitir alarmes precisos")
                    .setMessage("Para tentar tocar no horário escolhido, permita que o app programe alarmes e lembretes nas configurações do Android.")
                    .setPositiveButton("Abrir configurações") { _, _ ->
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                Uri.parse("package:$packageName")))
                        }
                    }
                    .setNegativeButton("Agora não", null).show()
            }
        }
    }
}
