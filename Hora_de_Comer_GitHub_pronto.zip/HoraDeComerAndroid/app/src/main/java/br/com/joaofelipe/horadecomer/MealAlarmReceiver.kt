package br.com.joaofelipe.horadecomer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

class MealAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("meal_id", 1)
        val meal = MealData.meals.firstOrNull { it.id == id } ?: return
        val prefs = context.getSharedPreferences("meal_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled_$id", true)) return

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "meal_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Lembretes das refeições", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Alarmes diários para lembrar os horários das refeições"
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), null)
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }
        val openApp = PendingIntent.getActivity(
            context, 900 + id, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Hora de comer, João Felipe! 🥗")
            .setContentText("Está na hora de: ${meal.name}")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Faça uma pausa para ${meal.name.lowercase()}. Escolha algo que goste e respeite sua fome."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
        manager.notify(1000 + id, notification)

        // Agende a próxima ocorrência diária.
        AlarmScheduler.schedule(context, id)
    }
}
