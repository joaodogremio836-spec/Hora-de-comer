package br.com.joaofelipe.horadecomer

data class Meal(val id: Int, val emoji: String, val name: String, val description: String, val defaultHour: Int, val defaultMinute: Int)

object MealData {
    val meals = listOf(
        Meal(1, "🌅", "Café da manhã", "Antes de sair para a escola", 6, 30),
        Meal(2, "🍎", "Lanche da manhã", "No intervalo da escola", 9, 30),
        Meal(3, "🍛", "Almoço", "Uma refeição completa", 12, 30),
        Meal(4, "🥪", "Lanche da tarde", "Uma pausa para recarregar", 16, 0),
        Meal(5, "🌙", "Jantar", "Sua refeição da noite", 19, 30)
    )
}
