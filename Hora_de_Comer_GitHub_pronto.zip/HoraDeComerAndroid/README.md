# Hora de Comer — projeto Android de João Felipe

Este é um projeto-fonte Android Studio (Kotlin) com ícone próprio e lembretes diários de refeições.

## Recursos
- Café da manhã, lanche da manhã, almoço, lanche da tarde e jantar.
- Horários editáveis no relógio de cada refeição.
- Ativar/desativar cada alarme.
- Notificações com som e vibração.
- Reprogramação após reiniciar o aparelho.
- Ícone personalizado.

## Como gerar o APK
1. Em um computador, instale o Android Studio atualizado.
2. Extraia o arquivo ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `HoraDeComerAndroid`.
4. Aguarde o Gradle sincronizar. É necessária conexão com a internet na primeira compilação para baixar as ferramentas.
5. Selecione **Build > Build APK(s)**.
6. O APK de depuração normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfira o APK para o seu Android e instale. O sistema pode pedir autorização para instalar apps dessa origem.

## Importante
- Ao abrir pela primeira vez, permita notificações.
- Em versões recentes do Android, vá às configurações do app e permita alarmes/lembretes ou alarmes precisos, se o sistema oferecer essa opção.
- Alguns fabricantes podem limitar alarmes em economia de bateria; se necessário, ajuste essa configuração para o app.
- O código tenta usar alarmes exatos quando permitido e recorre a alarmes aproximados quando não permitido. Nenhum app pode garantir som se o celular estiver desligado, sem bateria, no modo Não Perturbe ou com notificações bloqueadas.
- Os horários que vêm configurados são apenas sugestões. Ajuste à sua rotina. Este app não é uma dieta médica nem substitui orientação profissional.

## Requisitos
- Android Studio com Android SDK 35 instalado.
- JDK 17 ou compatível com a versão do Android Gradle Plugin usada.
